# Equipment Filters PWA

Prepared from the provided Equipment Filters HTML. It uses Firebase Authentication and Cloud Firestore for shared data, plus an installable PWA shell.

**Not published yet:** add your own Firebase Web App configuration in `firebase-config.js`, enable Email/Password authentication, create Firestore, publish `firestore.rules`, and create `access/{UID}` for each permitted user.

Roles:
- `admin`: read/write
- `editor`: read/write
- `viewer`: read-only

Access document fields: `active` (Boolean) and `role` (String).
Never put Google passwords or Firebase service-account private keys in this package.
See `FIREBASE_SETUP_AR.md`.
