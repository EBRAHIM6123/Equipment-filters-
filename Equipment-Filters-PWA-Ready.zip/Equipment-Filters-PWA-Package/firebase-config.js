// Replace the placeholders with the Web App config from Firebase Console.
// This is client configuration, not a password. Never add service-account private keys here.
window.FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "PASTE_PROJECT_ID_HERE.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID_HERE",
  storageBucket: "PASTE_PROJECT_ID_HERE.firebasestorage.app",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID_HERE",
  appId: "PASTE_APP_ID_HERE"
};
if (!firebase.apps.length) firebase.initializeApp(window.FIREBASE_CONFIG);
