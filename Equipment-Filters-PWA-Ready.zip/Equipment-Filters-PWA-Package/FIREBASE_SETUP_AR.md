# دليل إعداد Equipment Filters من الهاتف

هذه الحزمة جاهزة من ناحية الملفات، لكنها ليست منشورة بعد. ستحتاج إلى إنشاء مشروع Firebase مرة واحدة. لا ترسل كلمة مرور Gmail أو كلمات مرور الحسابات لأي شخص.

## أ) إنشاء مشروع السحابة
1. افتح Chrome على Android وانتقل إلى https://console.firebase.google.com/
2. سجّل الدخول بحساب Google.
3. اختر Create a project / Add project وأنشئ مشروعاً باسم متاح مثل `equipment-filters-xxxx`.
4. من لوحة المشروع اضغط `</>` (Add app / Web)، واكتب `Equipment Filters` ثم سجّل التطبيق.
5. انسخ إعدادات Web App التي تحتوي `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId`. يجب استبدال القيم `PASTE_...` في `firebase-config.js` بهذه القيم.

## ب) تفعيل تسجيل الدخول
1. Build → Authentication → Get started.
2. Sign-in method → Email/Password → Enable → Save.
3. من تبويب Users اضغط Add user وأنشئ حسابك بالبريد الإلكتروني وكلمة مرور قوية.
4. سجّل UID الظاهر بجانب حسابك في قائمة Users.

## ج) إنشاء قاعدة البيانات وقواعد الحماية
1. Build → Firestore Database → Create database. اختر الموقع المناسب بعناية.
2. من تبويب Rules الصق محتوى الملف `firestore.rules` ثم اضغط Publish.
3. افتح تبويب Data → Start collection.
4. اسم المجموعة: `access`.
5. Document ID: الصق UID الخاص بحسابك.
6. أضف `active` بنوع Boolean وقيمة `true`.
7. أضف `role` بنوع String وقيمة `admin`، ثم احفظ.
من دون مستند الوصول هذا لن يستطيع حسابك فتح التطبيق.

## د) إضافة أشخاص تسمح لهم
1. أضف حساباً لكل شخص من Authentication → Users → Add user.
2. انسخ UID الخاص به.
3. في Firestore → Data → `access` أنشئ مستنداً مع Document ID يساوي UID.
4. أضف `active` (Boolean) = `true` و`role` (String) = `viewer` أو `editor`.
5. لمنع وصوله، اجعل `active` = `false` أو احذف مستند الوصول.
لا تمنح دور admin إلا لمن تثق به. لا يمكن للمستخدمين تغيير صلاحياتهم من داخل التطبيق.

## هـ) النشر
الملفات تحتوي إعدادات Firebase Hosting وFirestore Rules. أسهل طريقة رسمية للنشر تستخدم Firebase CLI من جهاز كمبيوتر. من داخل مجلد المشروع نفّذ:
`npm install -g firebase-tools`
`firebase login`
`firebase use --add`
`firebase deploy --only firestore:rules,hosting`

بما أنك تستخدم هاتف Android فقط، فإن نشر مجلد كامل من الهاتف أصعب من إعداد المشروع نفسه. لا أستطيع نشره داخل حسابك تلقائياً من هنا. بعد إكمال خطوات Firebase، أرسل لقطة شاشة للمرحلة التي وصلت إليها (مع إخفاء البريد/UID وأي بيانات حساسة)، وسأرشدك خطوة بخطوة. لا ترسل كلمات المرور.

## و) التثبيت بعد النشر
- Android: افتح الرابط النهائي في Chrome → القائمة ⋮ → Install app أو Add to Home screen.
- iPhone: افتح الرابط في Safari → Share → Add to Home Screen.
- Laptop: افتح الرابط في Chrome أو Edge → Install.
يحتاج التطبيق إلى الإنترنت لتسجيل الدخول والمزامنة. بياناته لا تصبح مشتركة إلا بعد اكتمال إعداد Firebase ونشر الموقع.

## النسخ الاحتياطي
في Manage Data اضغط Copy data لنسخ JSON. للاستعادة، استخدم Import backup JSON واختر ملف JSON محفوظاً من التطبيق. لا تحذف البيانات القديمة قبل التأكد من نجاح الاستيراد.


## طريقة نشر تناسب من لديه هاتف Android فقط (Cloud Shell)

هذه الطريقة تستخدم أدوات Firebase من المتصفح بدلاً من تثبيت برامج على الهاتف. قد يكون العمل أسهل إذا فعّلت خيار **Desktop site** في Chrome.

1. بعد إنشاء مشروع Firebase، افتح صفحة المشروع من https://console.firebase.google.com/
2. اضغط أيقونة Cloud Shell / Terminal في أعلى الصفحة إذا كانت ظاهرة. إذا لم تظهر على الهاتف، افتح القائمة ⋮ في Chrome وفعّل **Desktop site**.
3. انتظر حتى تفتح نافذة Terminal داخل المتصفح. قد تحتاج إلى الموافقة على بدء Cloud Shell.
4. حمّل ملف `Equipment-Filters-PWA-Ready.zip` من هذه المحادثة إلى هاتفك.
5. في نافذة Cloud Shell افتح قائمة **More** ثم **Upload file** (قد تختلف تسمية القائمة حسب واجهة Google Cloud). اختر ملف ZIP من مجلد Downloads.
6. بعد انتهاء الرفع، الصق الأمر التالي واضغط Enter:
   `unzip Equipment-Filters-PWA-Ready.zip`
7. انتقل إلى مجلد الملفات:
   `cd Equipment-Filters-PWA-Package`
8. قبل النشر، يجب تعديل `firebase-config.js` ووضع إعدادات Web App التي نسختها من Firebase Console. افتح محرر Cloud Shell / Editor من واجهة Cloud Shell، وافتح هذا الملف، واستبدل فقط القيم `PASTE_...` بالقيم التي نسختها، ثم احفظ.
9. في Terminal نفّذ:
   `firebase use --add`
   واختر مشروعك من القائمة.
10. نفّذ:
   `firebase deploy --only firestore:rules,hosting`
11. إذا طلب منك تسجيل الدخول أو لم يعمل أمر ما، لا تجرّب أوامر عشوائية؛ أرسل لي صورة الشاشة مع إخفاء البريد وأي معلومات حساسة، وسأقول لك الخطوة التالية.

ملاحظة: Cloud Shell قد تكون واجهته ضيقة أو صعبة على شاشة الهاتف. إذا تعذّر فتحها أو رفع ZIP، لا يعني ذلك أن التطبيق فيه مشكلة؛ قد نحتاج إلى إكمال خطوة النشر من لابتوب لاحقاً.
